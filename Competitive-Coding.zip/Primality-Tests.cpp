// Fermat's little theorem

// If n is prime, then always returns true, If n is
// composite than returns false with high probability
// Higher value of k increases probability of correct
// result. Complexity klogn

bool isPrime(unsigned int n, int k = 10)
{
    // Corner cases
    if (n <= 1 || n == 4) return false;
    if (n <= 3) return true;

    // Try k times
    while (k > 0)
    {
        // Pick a random number in [2..n-2]
        // Above corner cases make sure that n > 4
        int a = 2 + rand()%(n-4);

        // Checking if a and n are co-prime
        if (__gcd(n, a) != 1)
            return false;

        if (power(a, n-1, n) != 1)
            return false;
        k--;
	}
	return true;
}

/* -------------------------------------------------------*/

//Miller Rabin TEST

bool miillerTest(int d, int n)
{
    // Pick a random number in [2..n-2]
    // Corner cases make sure that n > 4
    int a = 2 + rand() % (n - 4);

    // Compute a^d % n
    int x = power(a, d, n);

    if (x == 1  || x == n-1)
       return true;

    // Keep squaring x while one of the following doesn't
    // happen
    // (i)   d does not reach n-1
    // (ii)  (x^2) % n is not 1
    // (iii) (x^2) % n is not n-1
    while (d != n-1)
    {
        x = (x * x) % n;
        d *= 2;

        if (x == 1)      return false;
        if (x == n-1)    return true;
    }

    // Return composite
    return false;
}

// It returns false if n is composite and returns true if n
// is probably prime.  k is an input parameter that determines
// accuracy level. Higher value of k indicates more accuracy.
bool isPrime(int n, int k)
{
    // Corner cases
    if (n <= 1 || n == 4)  return false;
    if (n <= 3) return true;

    // Find r such that n = 2^d * r + 1 for some r >= 1
    int d = n - 1;
    while (d % 2 == 0)
        d /= 2;

    // Iterate given nber of 'k' times
    for (int i = 0; i < k; i++)
         if (!miillerTest(d, n))
              return false;

    return true;
}

/* -------------------------------------------------------*/

// To perform the Solovay-Strassen Primality Test
int calculateJacobian(int a, int n)
{
	if (!a)
		return 0;// (0/n) = 0

	int ans = 1;
	if (a < 0)
	{
		a = -a; // (a/n) = (-a/n)*(-1/n)
		if (n % 4 == 3)
			ans = -ans; // (-1/n) = -1 if n = 3 (mod 4)
	}

	if (a == 1)
		return ans;// (1/n) = 1

	while (a)
	{
		if (a < 0)
		{
			a = -a;// (a/n) = (-a/n)*(-1/n)
			if (n % 4 == 3)
				ans = -ans;// (-1/n) = -1 if n = 3 (mod 4)
		}

		while (a % 2 == 0)
		{
			a = a / 2;
			if (n % 8 == 3 || n % 8 == 5)
				ans = -ans;

		}

		swap(a, n);

		if (a % 4 == 3 && n % 4 == 3)
			ans = -ans;
		a = a % n;

		if (a > n / 2)
			a = a - n;

	}

	if (n == 1)
		return ans;

	return 0;
}

bool isPrime(int p, int iterations = 50)
{
	if (p < 2)
		return false;
	if (p != 2 && p % 2 == 0)
		return false;

	for (int i = 0; i < iterations; i++)
	{
		// Generate a random number a
		int a = rand() % (p - 1) + 1;
		int jacobian = (p + calculateJacobian(a, p)) % p;
		int mod = mpower(a, (p - 1) / 2, p);

		if (!jacobian || mod != jacobian)
			return false;
	}
	return true;
}

/* -------------------------------------------------------*/

// Function to check whether (2^p - 1)
// is prime or not.
bool isPrime(int p) {

// generate the number
int checkNumber = pow(2, p) - 1;

// First number of the series
int nextval = 4 % checkNumber;

// Generate the rest (p-2) terms
// of the series.
for (int i = 1; i < p - 1; i++)
	nextval = (nextval * nextval - 2) % checkNumber;

// now if the (p-1)th term is
// 0 return true else false.
return (nextval == 0);
}
