#include<bits/stdc++.h>
#define int long long
#define ld long double
#define pb push_back
#define ff first
#define ss second
#define PI acos(-1)
#define bp __builtin_popcount
#define all(x) x.begin(),x.end()
#define sp fixed<<setprecision
#define pii pair<long long,long long>
#define FAST ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
using namespace std;

int MOD = (1e9)+7;
const int N = 1e6+5;

signed main()
{
    FAST
    int tc=1;
    //cin>>tc;
    for(int ti=1;ti<=tc;ti++)
    {

    }
    return 0;
}
/*
Test Case
*/

int mpower(int x, int y, int p)
{
    int res = 1;
    x = x % p;
    while (y > 0)
    {
        if (y & 1){
            res = (res*x) % p;
        }
        y = y>>1;
        x = (x*x) % p;
    }
    return res;
}
int gcdex(int a, int b, int *x, int *y)
{
    if (a == 0){
        *x = 0, *y = 1;
        return b;
    }
    int x1, y1;
    int gcd = gcdex(b%a, a, &x1, &y1);
    *x = y1 - (b/a) * x1;
    *y = x1;
    return gcd;
}
int nCr(int n, int r)
{
    if(r>n){return 0;}
    if(n==r){return 1;}
    if(r==0){return 1;}
    int num=1,den=1;
    r=min(r,n-r);
    for(int i=1;i<=r;i++)
    {
        den*=i;
        den%=MOD;
        num*=(n+1-i);
        num%=MOD;
    }
    int inv = mpower(den,MOD-2,MOD)%MOD;
    return (num*inv)%MOD;
}

int nCr[N][N],nPr[N][N],fact[N];
void generate_comb()
{
    nCr[0][0] = 1;
    nPr[0][0] = 1;
    fact[0] = 1;
    for(int i=1;i<N;i++)
    {
        fact[i] = (i*fact[i-1])%MOD;
        nPr[0][i] = nCr[0][i]=0;
        nCr[i][0] = 1;
        nPr[i][0] = nCr[i][0];
    }
    for(int i=1;i<N;i++)
    {
        for(int j=1;j<N;j++)
        {
            if(i<j){continue;}
            else if(i==j){nCr[i][j]=1;}
            else
            {
                nCr[i][j] = (nCr[i-1][j]+ nCr[i-1][j-1])%MOD;;
                nPr[i][j] = (nCr[i][j]*fact[j])%MOD;
            }
        }
    }
}

int spf[N];
void sieve()
{
    for(int i=2;i<N;i++)
    {
        if(!spf[i])
        {
            spf[i]=i;
            for(int j=i*i;j<N;j+=i)
            {
                if(!spf[j]){spf[j]=i;}
            }
        }
    }
}

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
typedef tree<int,null_type,less_equal<int>,rb_tree_tag,tree_order_statistics_node_update> ordered_set;
/*
s.order_of_key(x)   - the number of elements in s less than x.
*s.find_by_order(x) - xth element in s in sorted order(0-based).
*/

Formulas -

Catalan Numbers -
Cn+1 = Sum of(Ci*Cn-i)(0 to n)
C0 = 1
Cn = (1/(n+1))*(2nCn)

nCr + nC(r+1) = (n+1)C(r+1)

