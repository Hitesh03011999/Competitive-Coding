//Static Convex Hull in NlogN

// A C++ program to find convex hull of a set of points. Refer
// https://www.geeksforgeeks.org/orientation-3-ordered-points/
// for explanation of orientation()
#include <iostream>
#include <stack>
#include <stdlib.h>
using namespace std;

struct Point
{
	int x, y;
};

// A global point needed for sorting points with reference
// to the first point Used in compare function of qsort()
Point p0;

// A utility function to find next to top in a stack
Point nextToTop(stack<Point> &S)
{
	Point p = S.top();
	S.pop();
	Point res = S.top();
	S.push(p);
	return res;
}

// A utility function to swap two points
int swap(Point &p1, Point &p2)
{
	Point temp = p1;
	p1 = p2;
	p2 = temp;
}

// A utility function to return square of distance
// between p1 and p2
int distSq(Point p1, Point p2)
{
	return (p1.x - p2.x)*(p1.x - p2.x) +
		(p1.y - p2.y)*(p1.y - p2.y);
}

// To find orientation of ordered triplet (p, q, r).
// The function returns following values
// 0 --> p, q and r are colinear
// 1 --> Clockwise
// 2 --> Counterclockwise
int orientation(Point p, Point q, Point r)
{
	int val = (q.y - p.y) * (r.x - q.x) -
			(q.x - p.x) * (r.y - q.y);

	if (val == 0) return 0; // colinear
	return (val > 0)? 1: 2; // clock or counterclock wise
}

// A function used by library function qsort() to sort an array of
// points with respect to the first point
int compare(const void *vp1, const void *vp2)
{
Point *p1 = (Point *)vp1;
Point *p2 = (Point *)vp2;

// Find orientation
int o = orientation(p0, *p1, *p2);
if (o == 0)
	return (distSq(p0, *p2) >= distSq(p0, *p1))? -1 : 1;

return (o == 2)? -1: 1;
}

// Prints convex hull of a set of n points.
void convexHull(Point points[], int n)
{
// Find the bottommost point
int ymin = points[0].y, min = 0;
for (int i = 1; i < n; i++)
{
	int y = points[i].y;

	// Pick the bottom-most or chose the left
	// most point in case of tie
	if ((y < ymin) || (ymin == y &&
		points[i].x < points[min].x))
		ymin = points[i].y, min = i;
}

// Place the bottom-most point at first position
swap(points[0], points[min]);

// Sort n-1 points with respect to the first point.
// A point p1 comes before p2 in sorted output if p2
// has larger polar angle (in counterclockwise
// direction) than p1
p0 = points[0];
qsort(&points[1], n-1, sizeof(Point), compare);

// If two or more points make same angle with p0,
// Remove all but the one that is farthest from p0
// Remember that, in above sorting, our criteria was
// to keep the farthest point at the end when more than
// one points have same angle.
int m = 1; // Initialize size of modified array
for (int i=1; i<n; i++)
{
	// Keep removing i while angle of i and i+1 is same
	// with respect to p0
	while (i < n-1 && orientation(p0, points[i],
									points[i+1]) == 0)
		i++;


	points[m] = points[i];
	m++; // Update size of modified array
}

// If modified array of points has less than 3 points,
// convex hull is not possible
if (m < 3) return;

// Create an empty stack and push first three points
// to it.
stack<Point> S;
S.push(points[0]);
S.push(points[1]);
S.push(points[2]);

// Process remaining n-3 points
for (int i = 3; i < m; i++)
{
	// Keep removing top while the angle formed by
	// points next-to-top, top, and points[i] makes
	// a non-left turn
	while (orientation(nextToTop(S), S.top(), points[i]) != 2)
		S.pop();
	S.push(points[i]);
}

// Now stack has the output points, print contents of stack
while (!S.empty())
{
	Point p = S.top();
	cout << "(" << p.x << ", " << p.y <<")" << endl;
	S.pop();
}
}

// Driver program to test above functions
int main()
{
	Point points[] = {{0, 3}, {1, 1}, {2, 2}, {4, 4},
					{0, 0}, {1, 2}, {3, 1}, {3, 3}};
	int n = sizeof(points)/sizeof(points[0]);
	convexHull(points, n);
	return 0;
}


/* --------------------------------------------------------------------*/

//Dynamic Convex Hull

// C++ program to add given a point p to a given
// convext hull. The program assumes that the
// point of given convext hull are in anti-clockwise
// order.
#include<bits/stdc++.h>
using namespace std;

// checks whether the point crosses the convex hull
// or not
int orientation(pair<int, int> a, pair<int, int> b,
				pair<int, int> c)
{
	int res = (b.second-a.second)*(c.first-b.first) -
			(c.second-b.second)*(b.first-a.first);

	if (res == 0)
		return 0;
	if (res > 0)
		return 1;
	return -1;
}

// Returns the square of distance between two input points
int sqDist(pair<int, int> p1, pair<int, int> p2)
{
	return (p1.first-p2.first)*(p1.first-p2.first) +
		(p1.second-p2.second)*(p1.second-p2.second);
}

// Checks whether the point is inside the convex hull or not
bool inside(vector<pair<int, int>> a, pair<int, int> p)
{
	// Initialize the centroid of the convex hull
	pair<int, int> mid = {0, 0};

	int n = a.size();

	// Multiplying with n to avoid floating point
	// arithmetic.
	p.first *= n;
	p.second *= n;
	for (int i=0; i<n; i++)
	{
		mid.first += a[i].first;
		mid.second += a[i].second;
		a[i].first *= n;
		a[i].second *= n;
	}

	// if the mid and the given point lies always
	// on the same side w.r.t every edge of the
	// convex hull, then the point lies inside
	// the convex hull
	for (int i=0, j; i<n; i++)
	{
		j = (i+1)%n;
		int x1 = a[i].first, x2 = a[j].first;
		int y1 = a[i].second,y2 = a[j].second;
		int a1 = y1-y2;
		int b1 = x2-x1;
		int c1 = x1*y2-y1*x2;
		int for_mid = a1*mid.first+b1*mid.second+c1;
		int for_p = a1*p.first+b1*p.second+c1;
		if (for_mid*for_p < 0)
			return false;
	}

	return true;
}

// Adds a point p to given convex hull a[]
void addPoint(vector<pair<int, int>> &a, pair<int, int> p)
{
	// If point is inside p
	if (inside(a, p))
		return;

	// point having minimum distance from the point p
	int ind = 0;
	int n = a.size();
	for (int i=1; i<n; i++)
		if (sqDist(p, a[i]) < sqDist(p, a[ind]))
			ind = i;

	// Find the upper tangent
	int up = ind;
	while (orientation(p, a[up], a[(up+1)%n])>=0)
		up = (up + 1) % n;

	// Find the lower tangent
	int low = ind;
	while (orientation(p, a[low], a[(n+low-1)%n])<=0)
		low = (n+low - 1) % n;

	// Initialize result
	vector<pair<int, int>>ret;

	// making the final hull by traversing points
	// from up to low of given convex hull.
	int curr = up;
	ret.push_back(a[curr]);
	while (curr != low)
	{
		curr = (curr+1)%n;
		ret.push_back(a[curr]);
	}

	// Modify the original vector
	ret.push_back(p);
	a.clear();
	for (int i=0; i<ret.size(); i++)
		a.push_back(ret[i]);
}

// Driver code
int main()
{
	// the set of points in the convex hull
	vector<pair<int, int> > a;
	a.push_back({0, 0});
	a.push_back({3, -1});
	a.push_back({4, 5});
	int n = a.size();

	pair<int, int> p = {0, 0};
	addPoint(a, p);

	// Print the modified Convex Hull
	for (auto e : a)
		cout << "(" << e.first << ", "
			<< e.second << ") ";

	return 0;
}

