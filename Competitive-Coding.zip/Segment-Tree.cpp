int t[2 * N];
void build()
{
  for (int i = N - 1; i > 0; --i) t[i] = t[i<<1] + t[i<<1|1];
}
void update(int p, int value)
{
  for (t[p += N] = value; p > 1; p >>= 1) t[p>>1] = t[p] + t[p^1];
}
int query(int l, int r) {
  int res = 0;
  for (l += N, r += N; l < r; l >>= 1, r >>= 1) {
    if (l&1) res += t[l++];
    if (r&1) res += t[--r];
  }
  return res;
}


/*------------------------------------------------------*/
int t[4*N],la[4*N];
void build(int n,int s,int e)
{
    if(s>e)return;
    else if(s==e)t[n]=a[s];
    else
    {
        int m=(s+e)/2;
        build(n*2+1,s,m);
        build(n*2+2,m+1,e);
        t[n] = t[2*n+1] + t[2*n+2];
    }
}
void update(int n,int s,int e,int l,int r,int val)
{
    if(la[n])
    {
        t[n]+=(e-s+1)*la[n];
        if(s!=e)la[2*n+1]+=la[n],la[2*n+2]+=la[n];
        la[n]=0;
    }
    if(s>e || s>r || e<l)return;
    if(l<=s && e<=r)
    {
        t[n]+=(e-s+1)*val;
        if(s!=e)la[2*n+1]+=val,la[2*n+2]+=val;
        return ;
    }
    int m=(s+e)/2;
    update(n*2+1,  s,m,l,r,val);
    update(n*2+2,m+1,e,l,r,val);
    t[n] = t[2*n+1]+t[2*n+2];
    return;
}
int query(int n,int s,int e,int l,int r)
{
    if(la[n])
    {
        t[n]+=(e-s+1)*la[n];
        if(s!=e)la[2*n+1]+=la[n],la[2*n+2]+=la[n];
        la[n]=0;
    }
    if(s>e || s>r || e<l)return 0;
    if(l<=s && e<=r) return t[n];
    int m=(s+e)/2;
    return query(n*2+1,s,m,l,r) + query(n*2+2,m+1,e,l,r);
}

/*------------------------------------------------------*/

int BIT[2*N];
void update(int n,int in,int val)
{
    for(;in<=n;in+=in&-in)BIT[in]+=val;
}
int query(int in)
{
    int ret=0;
    for(;in>0;in-=(in&-in))ret+=BIT[in];
    return ret;
}



