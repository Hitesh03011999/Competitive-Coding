vector<int> a[N];
int par[N][level];
int depth[N];
int lca(int u, int v)
{
    if (depth[v] < depth[u])swap(u, v);
    int diff = depth[v] - depth[u];
    for (int i=0; i<level; i++) if((diff>>i)&1)v = par[v][i];
    if (u==v) return u;
    for (int i=level-1; i>=0; i--) if(par[u][i] != par[v][i])u = par[u][i],v = par[v][i];
    return par[u][0];
}
int dist(int u, int v)
{
    if(u==v)return 0;
    int res = 0;
    int l = lca(u,v);
    return depth[u]+depth[v]-(2*depth[l]);
}
