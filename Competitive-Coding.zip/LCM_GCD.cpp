/*
NOTES -

1. Number of pairs with given LCM (L) and GCD (G) - If L/G has k unique prime factors, answer will be 2^(k-1).

2. Number of pairs with (i, N) with GCD (d) where d|N and 1 ≤ i ≤ N is Euler(N/d).
    where Euler(x) = (p1-1)*(p2-1)*...(pk-1)/(p1*p2*..pk)

3. Sum of GCD of pairs (i, N) where 1 ≤ i ≤ N (aka GCD SUM Function)
    gcdSum(N) = gcdSum(p1^a1) * gcdSum(p2^a2) * ... * gcdSum(pN^aN)
    where gcdSum(pi^ai) = ((ai + 1) * pi^a) - pi^(ai-1)

4. Sum of LCM of pairs (i, N) where 1 ≤ i ≤ N (aka LCM Sum Function)

5. Sum of GCD of all pairs (aka GCD Extreme)

6. Sum of LCM of all pairs (aka LCM Extreme)

/*---------------------------------------------------------------------------------*/


//LCM Extreme
#include <iostream>
#include <math.h>

using namespace std;

#define FOR(i, L, U) for(int i=(int)L; i<=(int)U; i++)
#define FORD(i, U, L) for(int i=(int)U; i>=(int)L; i--)

#define READ(x) freopen(x, "r", stdin)
#define WRITE(x) freopen(x, "w", stdout)

#define PB push_back

typedef unsigned long long ULL;

inline int src() { int ret; scanf("%d", &ret); return ret; }

#define MAX 1000000

ULL phi[MAX + 7];
ULL res[MAX + 7];

void generatePhi() {
    phi[1] = 1;
    for (int i = 2; i <= MAX; i++) {
        if (!phi[i]) {
            phi[i] = i - 1;
            for (int j = (i << 1); j <= MAX; j += i) {
                if (!phi[j]) phi[j] = j;
                phi[j] = phi[j] * (i-1) / i;
            }
        }
    }
}

void preCal() {
    for (int i = 1; i <= MAX; ++i) {
        for (int j = i; j <= MAX; j += i) {
            res[j] += (phi[i] * i);
        }
    }
}

ULL solve(int n) {
    ULL ret = res[n];
    ret += 1;
    ret = ret * n / 2;
    return ret;
}

int main()
{
    //READ("input.txt");
    //WRITE("output.txt");
    int i, j, k;
    int TC, tc;
    double cl = clock();

    TC = src();

    generatePhi();
    preCal();

    int n;

    FOR(tc, 1, TC) {
        n = src();
        printf("%llu\n", solve(n));
    }

    cl = clock() - cl;
    fprintf(stderr, "Total Execution Time = %lf seconds\n", cl / CLOCKS_PER_SEC);

    return 0;
}


/*---------------------------------------------------------------------------------*/
//GCD Extreme
#include <iostream>
#include <math.h>

using namespace std;

#define FOR(i, L, U) for(int i=(int)L; i<=(int)U; i++)
#define FORD(i, U, L) for(int i=(int)U; i>=(int)L; i--)

#define READ(x) freopen(x, "r", stdin)
#define WRITE(x) freopen(x, "w", stdout)

#define PB push_back

typedef unsigned long long ULL;

inline int src() { int ret; scanf("%d", &ret); return ret; }

#define MAX 1000000

uint bigPrime[MAX + 7];
ULL gcdSum[MAX + 7];
ULL DP[MAX + 7];

// Main idea for faster pre cal is to use result of previous gcdSum.
// Suppose we need to calc gcdSum(12), then we can use result of gcdSum(4)
// and multiply formula part for prime 3.
void preCal() {
    memset(bigPrime, -1, sizeof bigPrime);

    for (int i = 2; i <= MAX; ++i) {
        if (bigPrime[i] == -1) {
            bigPrime[i] = i;
            // Only for primes up to root of MAX
            if (i <= 2000)
                for (int j = i*i; j <= MAX; j += i) bigPrime[j] = i;
        }
    }

    gcdSum[1] = 1;
    DP[1] = 0;
    for (int i = 2; i <= MAX; ++i) {
        int p = bigPrime[i];
        int a = 0;
        ULL pa = 1;
        int tmp = i;

        while (tmp % p == 0) {
            a++;
            pa *= p;
            tmp /= p;
        }
        gcdSum[i] = ((a+1) * pa - a * (pa / p)) * gcdSum[tmp];
        DP[i] = DP[i-1] + gcdSum[i] - i;
    }
}

int main()
{
    //READ("input.txt");
    //WRITE("output.txt");
    int i, j, k;
    int TC, tc;
    double cl = clock();

    preCal();

    int n;

    while (scanf("%d", &n) == 1) {
        if (n == 0) break;

        printf("%llu\n", DP[n]);
    }

    cl = clock() - cl;
    fprintf(stderr, "Total Execution Time = %lf seconds\n", cl / CLOCKS_PER_SEC);

    return 0;
}

/*---------------------------------------------------------------------------------*/
//LCM Extreme
// ==================================================
// Problem  :   1375 - LCM Extreme
// Run time :   0.604 sec.
// Language :   C++
// ==================================================


#include <cstdio>
#include <algorithm>
using namespace std;

typedef     unsigned long long      ULL;

const int MAXN = 3e6 + 3;

int phi[MAXN];
ULL ans[MAXN];

template<class T>
inline T fastIn()
{
    register char c = 0;
    register T a = 0;
    bool neg = false;

    while(c < 33) c = getchar();

    if(c == '-') neg = true;
    else a = c - '0';

    while(c = getchar(), c > 33)
        a = a * 10 + (c - '0');

    return (neg? -a : a);
}

void sieve1()
{
    for(int i = 0; i < MAXN; ++i) phi[i] = i;

    for(int i = 0; i < MAXN; i+=2) phi[i] >>= 1;

    for(int i = 3; i < MAXN; i+=2) {
        if(phi[i] == i) {
            --phi[i];
            for(int j = i+i; j < MAXN; j+=i) phi[j] -= phi[j] / i;
        }
    }
}

void sieve2()
{
    fill(ans, ans+MAXN, 1);

    for(int i = 2; i < MAXN; ++i)
        for(int j = i; j < MAXN; j+=i)
            ans[j] += ULL(i) * phi[i];
}

int main()
{
    sieve1();
    sieve2();

    ans[0] = 0;
    for(int i = 1; i < MAXN; ++i)
        ans[i] = ans[i-1] + ((ans[i] - 1) >> 1) * i;

    int t = fastIn<int>();

    for(int tc = 1; tc <= t; ++tc) {
        int n = fastIn<int>();
        printf("Case %d: %llu\n", tc, ans[n]);
    }

    return 0;
}
