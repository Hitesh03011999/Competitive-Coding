#include<bits/stdc++.h>
#define pb push_back
#define ll long long
#define ld long double
#define pb push_back
#define ff first
#define ss second
#define sp fixed<<setprecision
#define pii pair<int,int>
#define FAST ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define bp __builtin_popcount
#define int ll
using namespace std;
ll MOD = (1e9)+7;
int F[6][6],AF[6][6];
void multiply(int a[6][6], int b[6][6])
{
    int mul[6][6];
    for (int i = 0; i < 6; i++)
    {
        for (int j = 0; j < 6; j++)
        {
            mul[i][j] = 0;
            for (int k = 0; k < 6; k++)
                mul[i][j] += (a[i][k]*b[k][j])%MOD,mul[i][j]%=MOD;
        }
    }

    for (int i=0; i<6; i++)
        for (int j=0; j<6; j++)
            a[i][j] = mul[i][j];
}
int power(int F[6][6], int n)
{
    int ans=0;
    int M[6][6];

    //Assign in M the actual F Matrix
    for(int i=0;i<6;i++)for(int j=0;j<6;j++)M[i][j]=AF[i][j];

    //Multiply with initial values given
    if(n==1)
    {
        ans+=(2*F[0][0])%MOD;ans%=MOD;
        ans+=(1*F[1][0])%MOD;ans%=MOD;
        ans+=(1*F[3][0])%MOD;ans%=MOD;
        ans+=(1*F[4][0])%MOD;ans%=MOD;
        return ans;
    }
    power(F, n/2);
    multiply(F, F);
    if (n%2) multiply(F, M);

    //Multiply with initial values given
    ans+=(2*F[0][0])%MOD;ans%=MOD;
    ans+=(1*F[1][0])%MOD;ans%=MOD;
    ans+=(1*F[3][0])%MOD;ans%=MOD;
    ans+=(1*F[4][0])%MOD;ans%=MOD;
    return ans;
}
int solve(int n)
{
    //Base Cases - Here 0,1
    if(n<=1)return n+1;

    //Call for non-base cases i.e n-1.
    // If base 1,2, call n-2.
    return power(F,n-1);
}
signed main()
{
    F[0][0]=2;
    F[1][0]=3;
    F[3][0]=2;
    F[4][0]=3;
    F[0][1]=1;
    F[1][2]=1;
    F[3][3]=2;
    F[4][3]=3;
    F[3][4]=1;
    F[4][5]=1;
    for(int i=0;i<6;i++)for(int j=0;j<6;j++)AF[i][j]=F[i][j];
    //AF is the copy of F
    FAST
    int tc=1;
    cin>>tc;
    for(int ti=1;ti<=tc;ti++)
    {
        int n;
        cin>>n;
        cout<<solve(n)<<endl;
    }
    return 0;
}
/*

 */

