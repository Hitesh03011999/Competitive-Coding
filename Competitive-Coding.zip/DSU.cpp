int get_root(int c)
{
    if(root[c]==c)return c;
    return root[c] = get_root(root[c]);
}
void _union(int a, int b)
{
    a = get_root(a);
    b = get_root(b);
    if(siz[a]>=siz[b])root[b]=a,siz[a]+=siz[b];
    else root[a]=b,siz[b]+=siz[a];
}
int init(int n)
{
    for(int i=1;i<=n;i++)root[i]=i,siz[i]=1;
}
